﻿namespace linux_prueba.Entities
{
    public partial class Materias
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public int CarreraId { get; set; }
    }
}
