﻿namespace linux_prueba.DTO
{
    public class MateriaDTO
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public int CarreraId { get; set; }
    }
}
